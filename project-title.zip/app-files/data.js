var APP_DATA = {
  "scenes": [
    {
      "id": "0-panorama_courtyard",
      "name": "Panorama_Courtyard",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.4507540393318372,
        "pitch": -0.02195628406799699,
        "fov": 1.4083983627516938
      },
      "linkHotspots": [
        {
          "yaw": 0.7948924039011196,
          "pitch": 0.10697235385400461,
          "rotation": 0,
          "target": "1-panorama_shop-1"
        },
        {
          "yaw": -1.6109963530819424,
          "pitch": -1.003455406180425,
          "rotation": 0,
          "target": "2-panorama_terrace-1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-panorama_shop-1",
      "name": "Panorama_Shop 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.6578347882408995,
        "pitch": 0.113271715385304,
        "fov": 1.4083983627516938
      },
      "linkHotspots": [
        {
          "yaw": 0.5235680488757595,
          "pitch": 0.03439223113359269,
          "rotation": 0,
          "target": "0-panorama_courtyard"
        },
        {
          "yaw": 0.859552256797258,
          "pitch": -0.3231028929846005,
          "rotation": 0,
          "target": "2-panorama_terrace-1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-panorama_terrace-1",
      "name": "Panorama_Terrace 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.3341920863393888,
          "pitch": 0.22492414850892573,
          "rotation": 0,
          "target": "1-panorama_shop-1"
        },
        {
          "yaw": 0.29394256681554864,
          "pitch": 0.19588060416611874,
          "rotation": 0,
          "target": "0-panorama_courtyard"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
